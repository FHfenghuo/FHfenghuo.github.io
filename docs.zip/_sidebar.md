* [首页](/)

* 基础教程
    * [准备工作](01/zhunbei/)
    * [选择浏览器](01/liulanqi/)
    * [购买服务器](01/fuwuqi/)
    * [安装finalshell](01/finalshell/)
    * [安装面板](01/mianban/)
    
* 搭建教程
    * [介绍](02/jieshao/)
    